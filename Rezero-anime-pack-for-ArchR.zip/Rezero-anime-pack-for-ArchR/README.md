Rezero anime pack made by yokoshigyu and otaku and 
a gamer who plays rocket league swide swipe ,brawl star ,
Minecraft and fortnite mobile soon I am also gona make 
packs for this games so make sure to check out my github 
if you are interested in more themes like this.

## License & Copyright

### Theme Code & Layout
The theme configuration (`theme.toml`), layout structure, and custom UI assets created for **rezero-phone-home** are licensed under the **[MIT License](LICENSE)**. You are free to use, modify, and redistribute the theme files with attribution.

### Artwork & Trademark Disclaimer
- **Re:Zero − Starting Life in Another World** (*Rem* and related characters) is © Tappei Nagatsuki / KADOKAWA CORPORATION.
- All character illustrations, wallpapers, and icons included or referenced in previews belong to their respective copyright holders and original fan artists.
- This is an unofficial, non-commercial fan-made theme created solely for personal use on the R36S handheld running **Arch R**. If you are an artist or rights holder and would like any artwork removed or credited differently, please open an issue or pull request.
 


